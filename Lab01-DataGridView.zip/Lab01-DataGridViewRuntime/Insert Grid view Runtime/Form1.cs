﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Insert_Grid_view_Runtime
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            dataGridView1.ColumnCount = 1;
            dataGridView1.Columns[0].Name = "Name";
        }

        private void insertBtn_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Add(nameTxt.Text);
            nameTxt.Clear();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
