﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Lab01_Scientific_Calculator
{
    public partial class Form1 : Form
    {

        int sign = 0;
        double num1;
        double num2;
        int add = 0;
        int sub = 0;
        int mul = 0;
        int div = 0;
        int modBit = 0;
        Boolean fl = false;
        String s, x;


        public Form1()
        {
            InitializeComponent();
        }

        private void btn_1_Click(object sender, EventArgs e)
        {
            if (sign == 0)
            {
                txtInput.Text = txtInput.Text + Convert.ToString(1);
            }
            else if (sign == 1)
            {
                txtInput.Text = Convert.ToString(1);
                sign = 0;
            }
            fl = true;
        }

        private void btn_2_Click(object sender, EventArgs e)
        {
            if (sign == 0)
            {
                txtInput.Text = txtInput.Text + Convert.ToString(2);
            }
            else if (sign == 1)
            {
                txtInput.Text = Convert.ToString(2);
                sign = 0;
            }
            fl = true;
        }

        private void btn_3_Click(object sender, EventArgs e)
        {
            if (sign == 0)
            {
                txtInput.Text = txtInput.Text + Convert.ToString(3);
            }
            else if (sign == 1)
            {
                txtInput.Text = Convert.ToString(3);
                sign = 0;
            }
            fl = true;
        }

        private void btn_4_Click(object sender, EventArgs e)
        {
            if (sign == 0)
            {
                txtInput.Text = txtInput.Text + Convert.ToString(4);
            }
            else if (sign == 1)
            {
                txtInput.Text = Convert.ToString(4);
                sign = 0;
            }
            fl = true;
        }

        private void btn_5_Click(object sender, EventArgs e)
        {
            if (sign == 0)
            {
                txtInput.Text = txtInput.Text + Convert.ToString(5);
            }
            else if (sign == 1)
            {
                txtInput.Text = Convert.ToString(5);
                sign = 0;
            }
            fl = true;
        }

        private void btn_6_Click(object sender, EventArgs e)
        {
            if (sign == 0)
            {
                txtInput.Text = txtInput.Text + Convert.ToString(6);
            }
            else if (sign == 1)
            {
                txtInput.Text = Convert.ToString(6);
                sign = 0;
            }
            fl = true;
        }

        private void btn_7_Click(object sender, EventArgs e)
        {
            if (sign == 0)
            {
                txtInput.Text = txtInput.Text + Convert.ToString(7);
            }
            else if (sign == 1)
            {
                txtInput.Text = Convert.ToString(7);
                sign = 0;
            }
            fl = true;
        }

        private void btn_8_Click(object sender, EventArgs e)
        {
            if (sign == 0)
            {
                txtInput.Text = txtInput.Text + Convert.ToString(8);
            }
            else if (sign == 1)
            {
                txtInput.Text = Convert.ToString(8);
                sign = 0;
            }
            fl = true;
        }

        private void btn_9_Click(object sender, EventArgs e)
        {
            if (sign == 0)
            {
                txtInput.Text = txtInput.Text + Convert.ToString(9);
            }
            else if (sign == 1)
            {
                txtInput.Text = Convert.ToString(9);
                sign = 0;
            }
            fl = true;
        }

        private void btn_0_Click(object sender, EventArgs e)
        {
            if (sign == 0)
            {
                txtInput.Text = txtInput.Text + Convert.ToString(0);
            }
            else if (sign == 1)
            {
                txtInput.Text = Convert.ToString(0);
                sign = 0;
            }
            fl = true;
        }

        private void reset_SignBits()
        {
            add = 0;
            sub = 0;
            mul = 0;
            div = 0;
            modBit = 0;
            fl = false;
        }
        private void btn_add_Click(object sender, EventArgs e)
        {
            if (txtInput.Text.Length != 0)
            {
                calculate();
                reset_SignBits();
                add = 1;
                sign = 1;
            }
        }


        private void btn_subtract_Click(object sender, EventArgs e)
        {
            if (txtInput.Text.Length != 0)
            {
                num2 = Convert.ToDouble(txtInput.Text);
                calculate();
                reset_SignBits();
                sub = 1;
                sign = 1;
            }
        }

        private void btn_multiply_Click(object sender, EventArgs e)
        {
            if (txtInput.Text.Length != 0)
            {
                calculate();
                reset_SignBits();
                mul = 1;
                sign = 1;
            }
        }

        private void btn_divide_Click(object sender, EventArgs e)
        {
            if (txtInput.Text.Length != 0)
            {
                calculate();
                reset_SignBits();
                div = 1;
                sign = 1;
            }
        }

        private void btn_equal_Click(object sender, EventArgs e)
        {
            if (txtInput.Text.Length != 0)
            {
                calculate();
                reset_SignBits();
            }
            sign = 1;
        }

        

        private void calculate()
        {
            if (txtInput.Text != ".")
            {
                num2 = Convert.ToDouble(txtInput.Text);
                if (fl == false)
                {
                    num1 = num2;
                }
                else if (add == 1)
                {
                    num1 = num1 + num2;
                }
                else if (sub == 1)
                {
                    num1 = num1 - num2;
                }
                else if (mul == 1)
                {
                    num1 = num1 * num2;
                }
                else if (div == 1)
                {
                    num1 = num1 / num2;
                }
                else if (modBit == 1)
                {

                    num2 = Convert.ToInt32(txtInput.Text);
                    num1 = Convert.ToInt32(num1 % num2);
                }

                else
                {
                    num1 = num2;
                }
                txtInput.Text = Convert.ToString(num1);

            }
        }


        private void btn_sin_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtInput.Text.Length != 0)
                {
                    double l;
                    l = Math.Sin(Convert.ToDouble(txtInput.Text));
                    txtInput.Text = Convert.ToString(l);
                }
                sign = 1;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_cos_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtInput.Text.Length != 0)
                {
                    double l;
                    l = Math.Cos(Convert.ToDouble(txtInput.Text));
                    txtInput.Text = Convert.ToString(l);
                }
                sign = 1;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_tan_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtInput.Text.Length != 0)
                {
                    double l;
                    l = Math.Tan(Convert.ToDouble(txtInput.Text));
                    txtInput.Text = Convert.ToString(l);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_sqrt_Click(object sender, EventArgs e)
        {
            double s, l;
            l = Convert.ToDouble(txtInput.Text);
            s = Math.Sqrt(l);
            txtInput.Text = Convert.ToString(s);
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            txtInput.Clear();
            sign = 0;
            num1 = 0;
            num2 = 0;
            reset_SignBits();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_pow2_Click(object sender, EventArgs e)
        {
            double s, l;
            l = Convert.ToDouble(txtInput.Text);
            s = Math.Pow(l,5);
            txtInput.Text = Convert.ToString(s);
        }

        private void btn_log_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtInput.Text.Length != 0)
                {
                    double l;
                    l = Math.Log(Convert.ToDouble(txtInput.Text));
                    txtInput.Text = Convert.ToString(l);
                }
                sign = 1;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


    }
}
